﻿using System.Web.UI;

namespace StateManagement.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}