﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StateManagement
{
    public partial class StateManagementExample : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // Get and display the Session Timeout.
                lblSessionTimeOut.Text = "Session timeout = " + Session.Timeout.ToString() + " mins";
                // Indicate whether this is a new session.
                if (Session.IsNewSession == true)
                {
                    lblIsNewSession.Text = "New session";
                }
                else
                {
                    lblIsNewSession.Text = "Existing session";
                }
                ShowApplicationVariables();
                ShowSessionVariables();
            }
        }

        protected void btnRemoveApplicationVariable_Click(object sender, EventArgs e)
        {
            Application.Remove(ddlApplicationVariableName.SelectedItem.ToString());
            ShowApplicationVariables();
        }

        protected void btnRemoveAllApplicationVariables_Click(object sender, EventArgs e)
        {
            Application.RemoveAll();
            ShowApplicationVariables();
        }

        protected void btnAddEditApplicationVariable_Click(object sender, EventArgs e)
        {
            if (txtApplicationVariableName.Text != "")
            {
                Application.Lock();
                Application[txtApplicationVariableName.Text] = txtApplicationVariableValue.Text;
                Application.UnLock();
                ShowApplicationVariables();
            }
        }

        protected void ddlApplicationVariableName_SelectedIndexChanged(object sender, EventArgs e)
        {
            object value = Application[ddlApplicationVariableName.SelectedValue];
            if (value == null)
            {
                lblApplicationVariableValue.Text = "";
            }
            else
            {
                lblApplicationVariableValue.Text = value.ToString();
            }
            ShowApplicationVariables();
            ShowSessionVariables();
        }

        protected void btnRemoveSessionVariable_Click(object sender, EventArgs e)
        {
            Session.Remove(ddlSessionVariableName.SelectedItem.ToString());
            ShowSessionVariables();
        }

        protected void btnRemoveAllSessionVariables_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            ShowSessionVariables();
        }

        protected void btnAddEditSessionVariable_Click(object sender, EventArgs e)
        {
            if (txtSessionVariableName.Text != "")
            {
                Session[txtSessionVariableName.Text] = txtSessionVariableValue.Text;
                ShowSessionVariables();
            }
        }

        protected void ddlSessionVariableName_SelectedIndexChanged(object sender, EventArgs e)
        {
            object value = Session[ddlSessionVariableName.SelectedValue];
            if (value == null)
            {
                lblSessionVariableValue.Text = "";
            }
            else
            {
                lblSessionVariableValue.Text = value.ToString();
            }
            ShowApplicationVariables();
            ShowSessionVariables();
        }

        private void ShowApplicationVariables()
        {
            string selectedVarText;
            if (ddlApplicationVariableName.SelectedIndex > -1)
            {
                // Store the text of any selected variable.
                selectedVarText = ddlApplicationVariableName.SelectedItem.Text;
            }
            else
            {
                selectedVarText = "";
            }

            // Get the updated list of application variables after clearing the dropdown list.
            ddlApplicationVariableName.Items.Clear();

            // Next, insert the names of all application variables into the list.
            for (int iCounter = 0; iCounter <= (Application.Count - 1); iCounter++)
            {
                ddlApplicationVariableName.Items.Add(Application.GetKey(iCounter));
            }
            if (ddlApplicationVariableName.Items.Count == 0)
            {
                // No application variable.
                lblApplicationVariableValue.Text = "";
            }
            else
            {
                if ((!Page.IsPostBack) | (selectedVarText == "") | (Application[selectedVarText] == null))
                {
                    // Show the value of the first application variable.
                    selectedVarText = ddlApplicationVariableName.Items[0].Text;
                }
                ddlApplicationVariableName.SelectedValue = selectedVarText;
                lblApplicationVariableValue.Text = Application[selectedVarText].ToString();
            }
        }

        private void ShowSessionVariables()
        {
            string selectedVarText;
            if (ddlSessionVariableName.SelectedIndex > -1)
            {
                // Store the text of any selected variable.
                selectedVarText = ddlSessionVariableName.SelectedItem.Text;
            }
            else
            {
                selectedVarText = "";
            }

            // Clear the dropdown list and get the updated list of session variables.
            ddlSessionVariableName.Items.Clear();

            // Next, insert the names of all session variables into the list.
            for (int iCounter = 0; iCounter <= (Session.Count - 1); iCounter++)
            {
                ddlSessionVariableName.Items.Add(Session.Keys[iCounter]);
            }
            if (ddlSessionVariableName.Items.Count == 0)
            {
                // No application variable.
                lblSessionVariableValue.Text = "";
            }
            else
            {
                if ((!Page.IsPostBack) | (selectedVarText == "") | (Session[selectedVarText] == null))
                {
                    // Show the value of the first session variable.
                    selectedVarText = ddlSessionVariableName.Items[0].Text;
                }
                ddlSessionVariableName.SelectedValue = selectedVarText;
                lblSessionVariableValue.Text = Session[selectedVarText].ToString();
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            // Force a postback to refresh the page.
            Server.Transfer("StateManagementExample.aspx");
        }
    }
}